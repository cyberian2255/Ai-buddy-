import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val lp = Properties().apply {
    val f = rootProject.file("local.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
fun prop(n: String, d: String) = lp.getProperty(n) ?: System.getenv(n) ?: d

android {
    namespace = "com.buddy.ai"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.buddy.ai"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        buildConfigField("String", "OPENROUTER_KEY", "\"${prop("OPENROUTER_API_KEY", "")}\"")
        buildConfigField("String", "MODEL", "\"${prop("BUDDY_MODEL", "meta-llama/llama-3.3-70b-instruct:free")}\"")
    }
    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
}
