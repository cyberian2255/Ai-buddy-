package com.buddy.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import kotlin.concurrent.thread

class BuddyService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var box: LinearLayout
    private lateinit var bubble: TextView
    private lateinit var icon: ImageView
    private lateinit var lp: WindowManager.LayoutParams
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private val main = Handler(Looper.getMainLooper())
    private val history = mutableListOf<Pair<String, String>>()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("buddy", "Buddy", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "buddy")
            .setContentTitle("Buddy's on duty")
            .setContentText("Tap the floating face to talk")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)

        tts = TextToSpeech(this) {
            if (it == TextToSpeech.SUCCESS) { tts?.language = Locale.getDefault(); tts?.setSpeechRate(1.1f); ttsReady = true }
        }
        buildOverlay()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        icon = ImageView(this).apply {
            setImageResource(R.drawable.buddy_icon)
            layoutParams = LinearLayout.LayoutParams(dp(64), dp(64))
        }
        bubble = TextView(this).apply {
            setBackgroundColor(0xEE242A32.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(dp(10), dp(6), dp(10), dp(6))
            textSize = 14f
            maxWidth = dp(240)
            visibility = View.GONE
        }
        box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(bubble); addView(icon)
        }
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(16); y = dp(200) }

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        icon.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true
                    if (moved) { lp.x = sx + dx; lp.y = sy + dy; wm.updateViewLayout(box, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) onTap()
            }
            true
        }
        wm.addView(box, lp)
    }

    private fun say(text: String, speak: Boolean = false) {
        bubble.text = text; bubble.visibility = View.VISIBLE
        main.removeCallbacksAndMessages(null)
        main.postDelayed({ if (!listening) bubble.visibility = View.GONE }, 8000)
        if (speak && ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "b")
    }

    private fun onTap() {
        if (tts?.isSpeaking == true) { tts?.stop(); return }
        if (listening) { recognizer?.stopListening(); return }
        startListening()
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { say("No speech service on this phone, chief."); return }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { listening = true; say("Listening...") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() { listening = false }
                override fun onError(e: Int) { listening = false; say("Didn't catch that, partner. Tap and try again.") }
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
                override fun onResults(r: Bundle?) {
                    listening = false
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank()) say("Heard nothing, kid.") else ask(t)
                }
            })
        }
        recognizer?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        })
    }

    private fun ask(text: String) {
        say("Thinking...")
        history += "user" to text
        thread {
            val reply = try {
                OpenRouter.chat(history.takeLast(10))
            } catch (e: Exception) {
                Log.e("Buddy", "call failed", e)
                null
            }
            main.post {
                if (reply == null) {
                    history.removeLast()
                    say("My brain hiccuped, chief. Tap me again.", true)
                } else {
                    history += "assistant" to reply
                    say(reply, true)
                }
            }
        }
    }

    override fun onDestroy() {
        recognizer?.destroy(); tts?.shutdown()
        if (::box.isInitialized) wm.removeView(box)
        super.onDestroy()
    }
}
