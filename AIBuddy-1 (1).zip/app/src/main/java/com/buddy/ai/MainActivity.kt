package com.buddy.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        status = TextView(this).apply { textSize = 18f; gravity = Gravity.CENTER }
        val start = Button(this).apply { text = "Wake the buddy up"; setOnClickListener { go() } }
        val stop = Button(this).apply {
            text = "Send him home"
            setOnClickListener { stopService(Intent(this@MainActivity, BuddyService::class.java)) }
        }
        root.addView(status); root.addView(start); root.addView(stop)
        setContentView(root)
        status.text = if (BuildConfig.OPENROUTER_KEY.isBlank())
            "No API key baked in, chief. Add OPENROUTER_API_KEY to local.properties." else "Ready when you are, partner."
    }

    private fun go() {
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) { requestPermissions(need.toTypedArray(), 1); return }
        if (!Settings.canDrawOverlays(this)) {
            status.text = "Flip on 'Display over other apps' for me, then tap again."
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startForegroundService(Intent(this, BuddyService::class.java))
        status.text = "I'm floating. Tap my face from anywhere and talk."
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        go()
    }
}
