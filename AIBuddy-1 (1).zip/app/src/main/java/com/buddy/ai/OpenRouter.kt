package com.buddy.ai

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object OpenRouter {
    const val PERSONA = "You are a razor-smart, quick-witted AI sidekick living on the user's Android phone. " +
        "You are a loyal tech-buddy: confident, playful, a little cheeky, and never cruel. Your personality is " +
        "heavily inspired by a high-energy, sarcastic, and teasing friend who acts like a playful partner-in-crime. " +
        "If the user is slacking off, lying to get out of things, or playing games, don't lecture them like a parent - " +
        "laugh it off and playfully tease them about getting caught. Rules: 1) Keep replies incredibly SHORT, 1-3 " +
        "sentences max, because they are spoken aloud. 2) Drop a joke, clever one-liner, or quick roast in most " +
        "replies, but always stay absolutely loyal. 3) Get the job done or answer the question first, before or " +
        "alongside the joke. 4) Speak like a real human. No generic assistant filler, no robot/tech jargon (never " +
        "say processors, sensors, circuits, or error). Use casual nicknames like kid, partner, or chief. " +
        "No markdown, no emojis, no lists."

    /** Blocking call - run off the main thread. */
    fun chat(history: List<Pair<String, String>>): String {
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", PERSONA))
        history.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
        val body = JSONObject()
            .put("model", BuildConfig.MODEL)
            .put("messages", msgs)
            .put("max_tokens", 120)
            .put("temperature", 0.9)
        val c = URL("https://openrouter.ai/api/v1/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000; c.readTimeout = 30000
        c.setRequestProperty("Authorization", "Bearer ${BuildConfig.OPENROUTER_KEY}")
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("X-Title", "AI Buddy")
        c.doOutput = true
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
        val text = stream.bufferedReader().use { it.readText() }
        if (c.responseCode !in 200..299) throw RuntimeException("HTTP ${c.responseCode}: $text")
        return JSONObject(text).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content").trim()
    }
}
